
package main;

import java.util.List;
import tools.ManipulaArquivo;

public class GeradorControle {
    public GeradorControle(String nomeDaClasse, List<String> atributo, String caminhoENomeDoArquivo, List<String> codigoControle){
        codigoControle.add("package Main;\nimport java.util.ArrayList;\nimport java.util.List;\n"
                + "public class Controle{\nprivate List<"+nomeDaClasse+"> lista = new ArrayList<>();"
                + "\npublic Controle(){\n}\npublic void limparLista(){\nlista.clear();\n}"
                + "\npublic void adicionar("+nomeDaClasse+" "+nomeDaClasse.toLowerCase()+"){\n"
                + "lista.add("+nomeDaClasse.toLowerCase()+");\n}"
                + "\npublic List<"+nomeDaClasse+"> listar(){\n"
                + "return lista;\n}"
                + "\npublic "+nomeDaClasse+" buscar(String "+atributo.get(0).split(";")[1]
                + "){\nfor(int i = 0; i<lista.size(); i++){\n"
                + "if(String.valueOf(lista.get(i).get"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+"()).equals("+atributo.get(0).split(";")[1].toLowerCase()+")){\n"
                + "return lista.get(i);\n}\n}\nreturn null;\n}"
                + "\npublic void alterar("+nomeDaClasse+" "+nomeDaClasse.toLowerCase()+", "+nomeDaClasse+" "+nomeDaClasse.toLowerCase()+"Antigo){\n"
                + "lista.set(lista.indexOf("+nomeDaClasse.toLowerCase()+"Antigo), "+nomeDaClasse.toLowerCase()+");\n}"
                + "\npublic void excluir("+nomeDaClasse+" "+nomeDaClasse.toLowerCase()+"){\n"
                + "lista.remove("+nomeDaClasse.toLowerCase()+");\n}\n}");
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        manipulaArquivo.
                salvarArquivo("C:\\Users\\k1i20\\Documents\\NetBeansProjects\\Cobaia3\\src\\Main\\Controle.java", codigoControle);
    }
}
