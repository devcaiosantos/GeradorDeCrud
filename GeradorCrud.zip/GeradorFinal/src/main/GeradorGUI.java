
package main;

import java.util.List;
import tools.ManipulaArquivo;

public class GeradorGUI {
    public GeradorGUI(String nomeDaClasse, List<String> atributo, String caminhoENomeDoArquivo, List<String> codigoGUI){
        codigoGUI.add("package Main;\n\n"+ "import java.awt.BorderLayout;\n" +
                      "import java.awt.CardLayout;\n" +
                      "import java.awt.Container;\n" +
                      "import java.awt.GridLayout;\n" +
                      "import java.awt.event.ActionEvent;\n" +
                      "import java.awt.event.ActionListener;\n" +
                      "import java.awt.event.WindowAdapter;\n" +
                      "import java.awt.event.WindowEvent;\n" +
                      "import java.util.ArrayList;\n" +
                      "import java.util.List;\n" +
                      "import javax.swing.JButton;\n" +
                      "import javax.swing.JCheckBox;\n" +
                      "import javax.swing.JFrame;\n" +
                      "import javax.swing.JLabel;\n" +
                      "import javax.swing.JOptionPane;\n" +
                      "import javax.swing.JPanel;\n" +
                      "import javax.swing.JScrollPane;\n" +
                      "import javax.swing.JTable;\n" +
                      "import javax.swing.JTextArea;\n" +
                      "import javax.swing.JTextField;\n" +
                      "import javax.swing.JToolBar;\n" +
                      "import javax.swing.table.DefaultTableModel;\n" +
                      "import tools.ManipulaArquivo;\n" +
                      "import java.sql.Date;\n" +
                      "import tools.DateTextField;\n" +
                      "import java.text.ParseException;\n" +
                      "import java.text.SimpleDateFormat;\n" +
                      "public class GUI extends JFrame {\n"
                    + "private Container cp;\n");
        
        for (int i = 0; i < atributo.size(); i++) {
            if(atributo.get(i).split(";")[0].equals("boolean")){
                codigoGUI.add("private JCheckBox cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+" = new JCheckBox("+"\""+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"\""+", false);");
            } else if(atributo.get(i).split(";")[0].equals("Date")){
                codigoGUI.add("private JLabel lb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+" = new JLabel(\"" + atributo.get(i).split(";")[1] + "\") ;");
                codigoGUI.add("private DateTextField tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+" = new DateTextField();");
            } else{
                codigoGUI.add("private JLabel lb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+" = new JLabel("+"\""+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"\""+");");
                codigoGUI.add("private JTextField tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+" = new JTextField(20);");
            }
        }
        
        codigoGUI.add("private JButton btAdicionar = new JButton(\"Adicionar\");");
        codigoGUI.add("private JButton btListar = new JButton(\"Listar\");");
        codigoGUI.add("private JButton btBuscar = new JButton(\"Buscar\");");
        codigoGUI.add("private JButton btAlterar = new JButton(\"Alterar\");");
        codigoGUI.add("private JButton btExcluir = new JButton(\"Excluir\");");
        codigoGUI.add("private JButton btSalvar = new JButton(\"Salvar\");");
        codigoGUI.add("private JButton btCancelar = new JButton(\"Cancelar\");");
        codigoGUI.add("private JButton btCarregarDados = new JButton(\"Carregar\");");
        codigoGUI.add("private JButton btGravar = new JButton(\"Gravar\");");
        
        codigoGUI.add("private JToolBar toolBar = new JToolBar();\n"
                    + "private JPanel painelNorte = new JPanel();\n"
                    + "private JPanel painelCentro = new JPanel();\n"
                    + "private JPanel painelSul = new JPanel();\n"
                    + "private JTextArea texto = new JTextArea();\n"
                    + "private JScrollPane scrollTexto = new JScrollPane();\n"
                    + "private JScrollPane scrollTabela = new JScrollPane();\n");
        
        codigoGUI.add("private String acao = \"\";\n"
                    + "private String chavePrimaria = \"\";\n");
        
        codigoGUI.add("private Controle controle = new Controle();\n"
                    + "private "+nomeDaClasse+" "+nomeDaClasse.toLowerCase()+" = new "+nomeDaClasse+"();");
        
        String auxColunas = "String[] colunas = new String[]{";
        for (int i = 0; i < atributo.size(); i++) {
            auxColunas+="\""+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"\"";
            if(i!=atributo.size()-1){
                auxColunas+=", ";
            }
        }
        auxColunas+="};";
        codigoGUI.add(auxColunas);
        
        codigoGUI.add("String[][] dados = new String[0]["+atributo.size()+"];");
        codigoGUI.add("DefaultTableModel model = new DefaultTableModel(dados, colunas);\n"
                    + "JTable tabela = new JTable(model);");
        codigoGUI.add("private JPanel painel1 = new JPanel(new GridLayout(1, 1));\n"
                    + "private JPanel painel2 = new JPanel(new GridLayout(1, 1));\n"
                    + "private CardLayout cardLayout;");
     
        
        codigoGUI.add("public GUI(){");
        codigoGUI.add("String caminhoENomeDoArquivo = "+"\""+"Dados"+nomeDaClasse+".csv"+"\";");
        codigoGUI.add("setDefaultCloseOperation(DISPOSE_ON_CLOSE);\n"
                    + "setSize(600, 400);\n"
                    + "setTitle("+"\""+"CRUD "+nomeDaClasse+"\""+");\n"
                    + "setLocationRelativeTo(null);\n");
        codigoGUI.add("cp = getContentPane();\n"
                    + "cp.setLayout(new BorderLayout());\n"
                    + "cp.add(painelNorte, BorderLayout.NORTH);\n"
                    + "cp.add(painelCentro, BorderLayout.CENTER);\n"
                    + "cp.add(painelSul, BorderLayout.SOUTH);");
        codigoGUI.add("cardLayout = new CardLayout();\n"
                    + "painelSul.setLayout(cardLayout);\n"
                    + "painel1.add(scrollTexto);\n"
                    + "painel2.add(scrollTabela);\n"
                    + "texto.setText(\"\\n\\n\\n\\n\\n\\n\");\n"
                    + "scrollTexto.setViewportView(texto);\n"
                    + "painelSul.add(painel1, \"Avisos\");\n"
                    + "painelSul.add(painel2, \"Listagem\");\n"
                    + "tabela.setEnabled(false);\n"
                    + "painelNorte.setLayout(new GridLayout(1, 1));\n"
                    + "painelNorte.add(toolBar);\n");
        codigoGUI.add("painelCentro.setLayout(new GridLayout("+String.valueOf(atributo.size()-1)+", 2));");
        
        for (int i = 1; i < atributo.size(); i++) {
            if(atributo.get(i).split(";")[0].equals("boolean")){
                codigoGUI.add("painelCentro.add(cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+");");
            } else{
                codigoGUI.add("painelCentro.add(lb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+");");
                codigoGUI.add("painelCentro.add(tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+");");
            }
        }
        
        codigoGUI.add("toolBar.add(lb"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+");");
        codigoGUI.add("toolBar.add(tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+");");
        codigoGUI.add("toolBar.add(btAdicionar);");
        codigoGUI.add("toolBar.add(btBuscar);");
        codigoGUI.add("toolBar.add(btListar);");
        codigoGUI.add("toolBar.add(btAlterar);");
        codigoGUI.add("toolBar.add(btExcluir);");
        codigoGUI.add("toolBar.add(btSalvar);");
        codigoGUI.add("toolBar.add(btCancelar);");
        
        codigoGUI.add("btAdicionar.setVisible(false);");
        codigoGUI.add("btAlterar.setVisible(false);");
        codigoGUI.add("btExcluir.setVisible(false);");
        codigoGUI.add("btSalvar.setVisible(false);");
        codigoGUI.add("btCancelar.setVisible(false);");
        
        for (int i = 1; i < atributo.size(); i++) {
            if(atributo.get(i).split(";")[0].equals("boolean")){
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEnabled(false);");
            } else{
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEditable(false);");
            }
        }
        codigoGUI.add("texto.setEditable(false);\n");
        
        codigoGUI.add("btCarregarDados.addActionListener(new ActionListener(){\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "ManipulaArquivo manipulaArquivo = new ManipulaArquivo();\n"
                    + "if (manipulaArquivo.existeOArquivo(caminhoENomeDoArquivo)) {\n"
                    + "String aux[];\n"
                    + nomeDaClasse+" "+nomeDaClasse.substring(0,1).toLowerCase()+";\n"
                    + "List<String> listaStringCsv = manipulaArquivo.abrirArquivo(caminhoENomeDoArquivo);\n"
                    + "for (String linha : listaStringCsv) {\n");
        codigoGUI.add("aux = linha.split("+"\""+";"+"\""+");");
        String auxNovo = nomeDaClasse.substring(0,1).toLowerCase()+" = new "+nomeDaClasse+"(";
        for (int i = 0; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("int")) {
                auxNovo+="Integer.valueOf(aux["+i+"])";  
            } else if(atributo.get(i).split(";")[0].equals("boolean")){
                auxNovo+="Boolean.valueOf(aux["+i+"].equals("+"\""+"Sim"+"\""+")?true:false)";
            } else{
                auxNovo+=atributo.get(i).split(";")[0].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[0].substring(1))+".valueOf(aux["+i+"])";
            }
            if (i!=atributo.size()-1) {
                auxNovo+=",";
            }
        }
        auxNovo+=");";
        codigoGUI.add(auxNovo);
        codigoGUI.add("controle.adicionar("+nomeDaClasse.substring(0,1).toLowerCase()+");");
        codigoGUI.add("}\n");
        codigoGUI.add("cardLayout.show(painelSul,"+"\""+"Listagem"+"\""+");");
        codigoGUI.add("} else{"
                    + "manipulaArquivo.criarArquivoVazio(caminhoENomeDoArquivo);\n}\n}\n});");
        
        codigoGUI.add("btGravar.addActionListener(new ActionListener() {\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "List<"+nomeDaClasse+"> lista"+nomeDaClasse+" = controle.listar();\n"
                    + "List<String> lista"+nomeDaClasse+"EmFormatoStringCSV = new ArrayList<>();\n"
                    + "for("+nomeDaClasse+" "+nomeDaClasse.substring(0,1).toLowerCase()+" : lista"+nomeDaClasse+"){\n"
                    + "lista"+nomeDaClasse+"EmFormatoStringCSV.add("+nomeDaClasse.substring(0,1).toLowerCase()+".toString());\n"
                    + "}\n"
                    + "new ManipulaArquivo().salvarArquivo(caminhoENomeDoArquivo, lista"+nomeDaClasse+"EmFormatoStringCSV);\n"
                    + "System.out.println(\"gravou\");\n"
                    + "}\n"
                    + "});");
        
        codigoGUI.add("btBuscar.addActionListener(new ActionListener() {\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "btAdicionar.setVisible(false);\n"
                    + "cardLayout.show(painelSul, \"Avisos\");\n"
                    + "scrollTexto.setViewportView(texto);\n"
                    + "if(tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".getText().trim().isEmpty()){\n"
                    + "JOptionPane.showMessageDialog(cp, "+"\""+atributo.get(0).split(";")[1].toUpperCase()+" nâo pode ser vazio\");\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".requestFocus();\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".selectAll();\n"
                    + "} else{\n");
        
        codigoGUI.add("try{");
        codigoGUI.add("                    chavePrimaria = tf" + atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1)) + ".getText();\n");
        codigoGUI.add(nomeDaClasse.toLowerCase() + " = controle.buscar(String.valueOf(tf" + atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1)) + ".getText()));\n");
        
        codigoGUI.add("if (" + nomeDaClasse.toLowerCase() + " == null) {\n"
                + "btAdicionar.setVisible(true);\n"
                + "btAlterar.setVisible(false);\n btExcluir.setVisible(false);");
        
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setSelected(false);");
                codigoGUI.add("cb" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + ".setEnabled(false);");
            } else {
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setText("+"\""+"\""+");");
            }
        }
        
        codigoGUI.add("texto.setText(\"Não encontrou na lista - pode Adicionar\\n\\n\\n\");\n");
        codigoGUI.add("} else{\n");
        
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setSelected("+nomeDaClasse.toLowerCase()+".is"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"());");
            } else {
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setText(String.valueOf("+nomeDaClasse.toLowerCase()+".get"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"()));");
            }
        }
        
        codigoGUI.add("btAlterar.setVisible(true);");
        codigoGUI.add("btExcluir.setVisible(true);");
        codigoGUI.add("texto.setText(\"Encontrou na lista - pode Alterar ou Excluir\\n\\n\\n\");");
        
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEnabled(false);");
            } else {
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEditable(false);");
            }
        }
        
        codigoGUI.add("}}catch(Exception Exception){\n"
                + "JOptionPane.showMessageDialog(cp, \"Atributo " + atributo.get(0).split(";")[1] + " inválido!\");\n"
                + "\n");

        codigoGUI.add("}\n}\n}\n});");
        
        codigoGUI.add("btAdicionar.addActionListener(new ActionListener(){\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "acao = \"adicionar\";\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setText(chavePrimaria);\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setEditable(false);\n"
                    + "tf"+atributo.get(1).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(1).split(";")[1].substring(1))+".requestFocus();\n"
                    + "btSalvar.setVisible(true);\n"
                    + "btCancelar.setVisible(true);\n"
                    + "btBuscar.setVisible(false);\n"
                    + "btListar.setVisible(false);\n"
                    + "btAlterar.setVisible(false);\n"
                    + "btExcluir.setVisible(false);\n"
                    + "btAdicionar.setVisible(false);\n"
                    + "texto.setText(\"Preencha os atributos\\n\\n\\n\\n\\n\");\n");
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEnabled(true);");
            } else{
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEditable(true);");
            }
        }
        codigoGUI.add("}\n});");
        
        codigoGUI.add("btAlterar.addActionListener(new ActionListener() {\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "acao = \"alterar\";\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setText(chavePrimaria);\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setEditable(false);\n"
                    + "tf"+atributo.get(1).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(1).split(";")[1].substring(1))+".requestFocus();\n"
                    + "btSalvar.setVisible(true);\n"
                    + "btCancelar.setVisible(true);\n"
                    + "btBuscar.setVisible(false);\n"
                    + "btListar.setVisible(false);\n"
                    + "btAlterar.setVisible(false);\n"
                    + "btExcluir.setVisible(false);\n"
                    + "texto.setText(\"Preencha os atributos\\n\\n\\n\\n\\n\");\n");
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEnabled(true);");
            } else{
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEditable(true);");
            }
        }
        codigoGUI.add("}\n});");
        
        codigoGUI.add("btCancelar.addActionListener(new ActionListener() {\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "btSalvar.setVisible(false);\n"
                    + "btCancelar.setVisible(false);\n"
                    + "btBuscar.setVisible(true);\n"
                    + "btListar.setVisible(true);\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setEditable(true);\n");
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setSelected(false);");
            } else{
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setText(\"\");");
            }
        }
        
        codigoGUI.add("tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".requestFocus();\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".selectAll();\n"
                    + "texto.setText(\"Cancelou\\n\\n\\n\\n\\n\");\n");
        
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEnabled(false);");
            } else{
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEditable(false);");
            }
        }
        codigoGUI.add("}\n});");
        
        codigoGUI.add("btSalvar.addActionListener(new ActionListener() {\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n");
        codigoGUI.add("SimpleDateFormat sdf = new SimpleDateFormat(\"dd/MM/yyyy\");\n"
                    + "SimpleDateFormat sdfEUA = new SimpleDateFormat(\"yyyy-MM-dd\");\n"
                    + "sdf.setLenient(false);");
        codigoGUI.add("if (acao.equals(\"alterar\")) {");
        codigoGUI.add(nomeDaClasse + " " + nomeDaClasse.toLowerCase() + "Antigo  = " + nomeDaClasse.toLowerCase() + ";");
        codigoGUI.add("");
        
        int contDate = 0;
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add(nomeDaClasse.toLowerCase()+".set"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"(cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".isSelected());");
            } else{
                if (atributo.get(i).split(";")[0].equals("int")) {
                    codigoGUI.add(nomeDaClasse.toLowerCase()+".set"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"(Integer.valueOf(tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".getText()));");
                } else if(atributo.get(i).split(";")[0].equals("Date")){
                    if (contDate!=0) {
                        codigoGUI.add("try {\n"
                        + "data = sdf.parse(tf" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + ".getText());\n"
                        + "" + nomeDaClasse.toLowerCase() + ".set" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + "(Date.valueOf(sdfEUA.format(data)));\n"
                        + "} catch (ParseException ex) {\n"
                        + "}");
                    } else{
                    codigoGUI.add("java.util.Date data = new java.util.Date();\n"
                        + "try {\n"
                        + "data = sdf.parse(tf" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + ".getText());\n"
                        + "" + nomeDaClasse.toLowerCase() + ".set" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + "(Date.valueOf(sdfEUA.format(data)));\n"
                        + "} catch (ParseException ex) {\n"
                        + "}");
                    contDate++;
                }
                } else{
                    codigoGUI.add(nomeDaClasse.toLowerCase()+".set"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"("+atributo.get(i).split(";")[0].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[0].substring(1))+".valueOf(tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".getText()));");
                }
            }
        }
        
        codigoGUI.add("controle.alterar("+nomeDaClasse.toLowerCase()+", "+nomeDaClasse.toLowerCase()+"Antigo);\n"
                    + "texto.setText(\"Registro alterado\\n\\n\\n\\n\\n\");\n"
                    + "} else {\n"
                    + nomeDaClasse.toLowerCase()+" = new "+nomeDaClasse+"();\n");
        contDate = 0;
        for (int i = 0; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add(nomeDaClasse.toLowerCase()+".set"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"(cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".isSelected());");
            } else{
                if (atributo.get(i).split(";")[0].equals("int")) {
                    codigoGUI.add(nomeDaClasse.toLowerCase()+".set"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"(Integer.valueOf(tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".getText()));");
                } else if(atributo.get(i).split(";")[0].equals("Date")){
                    if (contDate!=0) {
                        codigoGUI.add("try {\n"
                        + "data = sdf.parse(tf" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + ".getText());\n"
                        + "" + nomeDaClasse.toLowerCase() + ".set" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + "(Date.valueOf(sdfEUA.format(data)));\n"
                        + "} catch (ParseException ex) {\n"
                        + "}");
                    } else{
                    codigoGUI.add("java.util.Date data = new java.util.Date();\n"
                        + "try {\n"
                        + "data = sdf.parse(tf" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + ".getText());\n"
                        + "" + nomeDaClasse.toLowerCase() + ".set" + atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1)) + "(Date.valueOf(sdfEUA.format(data)));\n"
                        + "} catch (ParseException ex) {\n"
                        + "}");
                    }
                    contDate++;
                }else{
                    codigoGUI.add(nomeDaClasse.toLowerCase()+".set"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"("+atributo.get(i).split(";")[0].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[0].substring(1))+".valueOf(tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".getText()));");
                }
            }
        }
        
        codigoGUI.add("controle.adicionar("+nomeDaClasse.toLowerCase()+");\n"
                    + "texto.setText(\"Foi adicionado um novo registro\\n\\n\\n\\n\\n\");\n"
                    + "}\n"
                    + "btSalvar.setVisible(false);\n"
                    + "btCancelar.setVisible(false);\n"
                    + "btBuscar.setVisible(true);\n"
                    + "btListar.setVisible(true);\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setEditable(true);");
        
        codigoGUI.add("tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".requestFocus();\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".selectAll();\n");
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setSelected(false);");
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEnabled(true);");
            } else{
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setText(\"\");");
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEditable(false);");
            }
        }

        codigoGUI.add("}\n});\n");
        
        codigoGUI.add("btExcluir.addActionListener(new ActionListener() {\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setText(chavePrimaria);\n"
                    + "if (JOptionPane.YES_OPTION\n"
                    + "== JOptionPane.showConfirmDialog(null,\n"
                    + "\"Confirma a exclusão do registro <Nome = \" + "+nomeDaClasse.toLowerCase()+".get"+atributo.get(1).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(1).split(";")[1].substring(1))+"() + \">?\", \"Confirm\",\n"
                    + "JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE)) {\n"
                    + "controle.excluir("+nomeDaClasse.toLowerCase()+");\n"
                    + "}\n"
                    + "btBuscar.setVisible(true);\n"
                    + "btListar.setVisible(true);\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".setEditable(true);");
        
        for (int i = 1; i < atributo.size(); i++) {
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setSelected(false);");
                codigoGUI.add("cb"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setEnabled(true);");
            } else{
                codigoGUI.add("tf"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+".setText(\"\");");
            }
        }
        
        codigoGUI.add("tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".requestFocus();\n"
                    + "tf"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+".selectAll();\n"
                    + "btExcluir.setVisible(false);\n"
                    + "btAlterar.setVisible(false);\n"
                    + "texto.setText(\"Excluiu o registro de \""+"+ "+nomeDaClasse.toLowerCase()+".get"+atributo.get(0).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(0).split(";")[1].substring(1))+"() + \" - \""+"+ "+nomeDaClasse.toLowerCase()+".get"+atributo.get(1).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(1).split(";")[1].substring(1))+"() + \"\\n\\n\\n\\n\\n\");");
        codigoGUI.add("}\n});\n");
        
        codigoGUI.add("btListar.addActionListener(new ActionListener() {\n"
                    + "@Override\n"
                    + "public void actionPerformed(ActionEvent e) {\n"
                    + "List<"+nomeDaClasse+"> l"+nomeDaClasse.substring(0,1).toLowerCase()+" = controle.listar();");
        
        String auxAt = "String[] colunas = {";
        for (int i = 0; i < atributo.size(); i++) {
            auxAt+="\""+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"\"";
            if (i!=atributo.size()-1) {
                auxAt+=", ";
            }
        }
        auxAt+="};";
        codigoGUI.add(auxAt);
        
        codigoGUI.add("Object[][] dados = new Object[l"+nomeDaClasse.substring(0,1).toLowerCase()+".size()][colunas.length];\n"
                    + "String aux[];\n"
                    + "for(int i = 0; i < l"+nomeDaClasse.substring(0,1).toLowerCase()+".size(); i++){\n"
                    + "aux = l"+nomeDaClasse.substring(0,1).toLowerCase()+".get(i).toString().split(\";\");\n"
                    + "for (int j = 0; j < colunas.length; j++) {\n"
                    + "dados[i][j] = aux[j];\n"
                    + "}\n"
                    + "}\n"
                    + "cardLayout.show(painelSul, \"Listagem\");\n"
                    + "scrollTabela.setPreferredSize(tabela.getPreferredSize());\n"
                    + "painel2.add(scrollTabela);\n"
                    + "scrollTabela.setViewportView(tabela);\n"
                    + "model.setDataVector(dados, colunas);\n"
                    + "btAlterar.setVisible(false);\n"
                    + "btExcluir.setVisible(false);\n"
                    + "btAdicionar.setVisible(false);\n");
        codigoGUI.add("}\n});\n");
        
        codigoGUI.add("addWindowListener(new WindowAdapter() {\n"
                + "@Override\n"
                + "public void windowClosing(WindowEvent e) {\n"
                + "btGravar.doClick();\n"
                + "dispose();\n");
        codigoGUI.add("}\n});\n");
        
        codigoGUI.add("setVisible(true);\n");
        codigoGUI.add("btCarregarDados.doClick();");
        
        codigoGUI.add("}");
        codigoGUI.add("}");
        
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        manipulaArquivo.
                salvarArquivo("C:\\Users\\k1i20\\Documents\\NetBeansProjects\\Cobaia3\\src\\Main\\GUI.java", codigoGUI);
    }
    
}
