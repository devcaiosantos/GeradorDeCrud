
package main;

import java.util.List;
import tools.ManipulaArquivo;

public class GeradorMain {
    
    public GeradorMain(String nomeDaClasse, List<String> atributo, String caminhoENomeDoArquivo, List<String> codigoMain){
        codigoMain.add("package Main;\npublic class Main{\npublic static void main(String[] args){\nGUI gui = new GUI();\n}\n}");
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        manipulaArquivo.
                salvarArquivo("C:\\Users\\k1i20\\Documents\\NetBeansProjects\\Cobaia3\\src\\Main\\Main.java", codigoMain);
    }
    
}
