
package main;

import java.util.List;
import tools.ManipulaArquivo;

public class GeradorObjeto {
    
    public GeradorObjeto(String nomeDaClasse, List<String> atributo, String caminhoENomeDoArquivo, List<String> codigoObjeto){
        codigoObjeto.add("package Main;\n"
                + "import java.sql.Date;\n"
                + "public class " + nomeDaClasse + " {");
        for (int i = 0; i < atributo.size(); i++) {
            String aux[] = atributo.get(i).split(";");
            codigoObjeto.add("private " + aux[0] + " " + aux[1] + ";");
        }

        codigoObjeto.add("\n"
                + " public " + nomeDaClasse + "() {\n"
                + "    }");
        
        String s = "public "+nomeDaClasse+"(";
        for (int i = 0; i < atributo.size(); i++) {
            String aux[] = atributo.get(i).split(";");
            s+=aux[0]+" "+aux[1]+",";
        }
        s = s.substring(0, s.length()-1);
        s+="){";
        
        codigoObjeto.add(s);
        
        for (int i = 0; i < atributo.size(); i++) {
            String aux[] = atributo.get(i).split(";");
            codigoObjeto.add("this."+aux[1]+" = "+" "+aux[1]+";");
        }
        codigoObjeto.add("}");

        for (int i = 0; i < atributo.size(); i++) {
            String aux[] = atributo.get(i).split(";");
            if (atributo.get(i).split(";")[0].equals("boolean")) {
                codigoObjeto.add("public boolean is"+atributo.get(i).split(";")[1].substring(0, 1).toUpperCase().concat(atributo.get(i).split(";")[1].substring(1))+"(){\n"
                        + "return "+atributo.get(i).split(";")[1].toLowerCase()+";\n"
                        + "}");
            }
            codigoObjeto.add("public "+atributo.get(i).split(";")[0]+" get"+aux[1].substring(0, 1).toUpperCase().concat(aux[1].substring(1))+"(){\nreturn "+aux[1]+";\n}");
            codigoObjeto.add("public void set"+aux[1].substring(0, 1).toUpperCase().concat(aux[1].substring(1))+"("+aux[0]+" "+aux[1]+"){\nthis."+aux[1]+"="+aux[1]+";\n}");
        }
        
        codigoObjeto.add("@Override\n"
                       + "public String toString() {");
        String auxToString = "return ";
        for (int i = 0; i < atributo.size(); i++) {
            auxToString += atributo.get(i).split(";")[1].toLowerCase();
            if (i!=atributo.size()-1) {
                auxToString += " + \";\" + ";
            }
        }
        codigoObjeto.add(auxToString);
        codigoObjeto.add(";\n}");
        
        codigoObjeto.add("\n}");
        ManipulaArquivo manipulaArquivo = new ManipulaArquivo();
        manipulaArquivo.
                salvarArquivo("C:\\Users\\k1i20\\Documents\\NetBeansProjects\\Cobaia3\\src\\Main\\"+nomeDaClasse+".java", codigoObjeto);
    }
    
}
