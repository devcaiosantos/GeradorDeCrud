package main;

import java.util.ArrayList;
import java.util.List;

public class Main {
    
    public static void main(String[] args) {
        String nomeDaClasse = "Paciente";
        List<String> atributo = new ArrayList<>();
        
        List<String> codigoObjeto = new ArrayList<>();
        List<String> codigoControle = new ArrayList<>();
        List<String> codigoGUI = new ArrayList<>();
        List<String> codigoMain = new ArrayList<>();
        
        String caminhoENomeDoArquivo = "DadosProduto.csv";//C:\Users\k1i20\Documents\NetBeansProjects\Cobaia3
        atributo.add("long;id");
        atributo.add("double;preco");
        atributo.add("int;cadastro");
        atributo.add("Date;nascimento");
        atributo.add("Date;pastori");
        
        GeradorMain gm = new GeradorMain(nomeDaClasse, atributo, caminhoENomeDoArquivo, codigoMain);
        GeradorObjeto go = new GeradorObjeto(nomeDaClasse, atributo, caminhoENomeDoArquivo, codigoObjeto);
        GeradorControle gc = new GeradorControle(nomeDaClasse, atributo, caminhoENomeDoArquivo, codigoControle);
        GeradorGUI gg = new GeradorGUI(nomeDaClasse, atributo, caminhoENomeDoArquivo, codigoGUI);
    }
}
